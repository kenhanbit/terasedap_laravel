<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terasedap - Menu</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/styles.css')); ?>" />
</head>

<body>
    <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert-warning">
        Please scan the qr code
    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <nav>
        <center>
            <div class="logo">
                <a href="<?php echo e(route('food-items')); ?>">
                    <img src="<?php echo e(asset('images/terasedap_logo.png')); ?>" alt="logo" />
                </a>
            </div>
        </center>
        <div class="cart-icon">
            <a href="<?php echo e(route('cart.view')); ?>">
                <img src="<?php echo e(asset('images/cart.png')); ?>" alt="cart" />
            </a>
        </div>
    </nav>
    
    <div class="motto">Experience Indonesian Culinary</div>
    <div class="centered-list">
        <ul class="horizontal-list">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li onclick="scrollToSection('<?php echo e($category->name); ?>')"><?php echo e($category->name); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
	<div class="scroll-target" id="<?php echo e($category->name); ?>">
        <center>
            <h1 class="list"><?php echo e($category->name); ?></h1>
        </center>


        <div class="menu">
            <div class="menu-list">
                <?php $__currentLoopData = $foodItems->where('category_id', $category->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.menu-card', ['item' => $item]);

$__html = app('livewire')->mount($__name, $__params, 'cI0eSFA', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
        </div>

	</div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <script>
    function scrollToSection(sectionId) {
        const section = document.getElementById(sectionId);

        if (section) {
            section.scrollIntoView({
                behavior: "smooth"
            });
        }
    }
    </script>

</body>

</html><?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/display_food_items.blade.php ENDPATH**/ ?>