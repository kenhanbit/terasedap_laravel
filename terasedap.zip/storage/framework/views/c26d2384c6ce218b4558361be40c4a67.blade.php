<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
  <path stroke-linecap="round" stroke-width="1.5" d="M3 7h18M3 12h18M3 17h18"/>
</svg>