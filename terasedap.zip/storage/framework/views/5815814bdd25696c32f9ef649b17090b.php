<svg style="width:20px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
  <path d="M18 12.75H6c-.41 0-.75-.34-.75-.75s.34-.75.75-.75h12c.41 0 .75.34.75.75s-.34.75-.75.75z"/>
</svg><?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\storage\framework\views/765fb6c26481b7f69834fb6fdafa2146.blade.php ENDPATH**/ ?>