<div class="logo">
    <a href="<?php echo e(route('food-items')); ?>">
        <img src="<?php echo e(asset('images/terasedap_logo.png')); ?>" alt="Logo" style="height: 10vh;width:auto;">
    </a>
</div><?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/components/logo.blade.php ENDPATH**/ ?>