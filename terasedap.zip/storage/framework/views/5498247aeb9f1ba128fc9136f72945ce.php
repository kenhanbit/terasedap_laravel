<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/styles.css')); ?>" />
    <title>Document</title>
</head>

<body>
    <nav>
        <center>
            <div class="logo">
                <a href="<?php echo e(route('food-items')); ?>">
                    <img src="<?php echo e(asset('images/terasedap_logo.png')); ?>" alt="logo" />
                </a>
            </div>
        </center>
    </nav>

    <div class="motto">Experience Indonesian <br />Culinary</div>

    <br />
    <div class="container">
        <center>
            <?php if($foodItem->image): ?>
            <img src="<?php echo e(asset('images/' . $foodItem->image)); ?>" alt="<?php echo e($foodItem->name); ?>">
            <?php else: ?>
            <p>No image available</p>
            <?php endif; ?>
        </center>
        <div class="text">
            <h2 class="title"><?php echo e($foodItem->name); ?></h2>
            <div class="food-price">Rp.<?php echo e($foodItem->price); ?></div>
            <p>
                <?php echo e($foodItem->description); ?>

            </p>
        </div>
    </div>

</body>

</html><?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/fooditem_description.blade.php ENDPATH**/ ?>