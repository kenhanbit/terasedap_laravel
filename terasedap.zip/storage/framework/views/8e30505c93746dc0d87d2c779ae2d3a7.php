<div>
   
    <footer>
        <div class="row">
            <div class="col">
                <img src="<?php echo e(asset('images/terasedap_logo.png')); ?>" class="logofoot">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            </div>
            <div class="col">
                <h3>Location</h3>
                <p>lorem ipsum</p>
                <p>lorem ipsum</p>
                <p class="email-id">email</p>
                <h4>+0121872718724</h4>
            </div>
            <div class="col">
                <a href="https://www.instagram.com/terasedap/">
                <div class="social-icon"> 
                   <i class="fa-brands fa-instagram fa-xl"></i>
                   terasedap
                </div>
                </a>
            </div> 
        </div>
    </footer>
</div><?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/components/footer.blade.php ENDPATH**/ ?>