<div class="logo">
    <a href="{{ route('food-items') }}">
        <img src="{{ asset('images/terasedap_logo.png') }}" alt="Logo" style="height: 10vh;width:auto;">
    </a>
</div>