{{ $url }} <br>
{{ $code }}