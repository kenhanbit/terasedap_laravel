<?php

namespace App\Livewire\Components;

use Livewire\Component;

class NotesModal extends Component
{
    public function render()
    {
        return view('livewire.components.notes-modal');
    }
}
