<a href="<?php echo e(route('food-item.edit', $detail->id)); ?>">
    <div wire:transition class="admin-menu">
        <div class="menu-detail" style="display: flex; flex-direction:column; justify-content:space-between">
            <div>
                <?php echo e($detail->name); ?>

            </div>
            <div>
                Rp. <?php echo e(number_format($detail->price, 0, '', '.')); ?>

            </div>
        </div>
        <div class="menu-image">
            <img src="<?php echo e(asset('images/' . $detail->image)); ?>" alt="<?php echo e($detail->name); ?>">
        </div>
    </div>
</a><?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/livewire/components/admin-menu.blade.php ENDPATH**/ ?>