<div class="table-order <?php echo e($detail->status); ?>" wire:key="<?php echo e($detail->id); ?>" x-on:click="$dispatch('open-modal', { name : '<?php echo e($detail->order_code); ?>'})">
    <div style="text-align: center">
        <div>
            <h3>
                Table: <?php echo e($detail->table_number); ?>

            </h3>
        </div>
        <div>
            <?php echo e($detail->order_code); ?>

        </div>
    </div>
</div><?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/livewire/components/admin-orders.blade.php ENDPATH**/ ?>