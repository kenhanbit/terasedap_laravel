<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/styles.css')); ?>" />
    <title>Document</title>
</head>

<body>

    <div class="navbar">
        <div>
            <img src="<?php echo e(asset('images/terasedap_logo.png')); ?>" alt="logo" />
        </div>
        <ul>
            <li><a href="#">Menu</a></li>
            <li><a href="#">Orders</a></li>
            <li><a href="#">Logout</a></li>
        </ul>
    </div>


    <center>
        <div>

            <h2>Edit Food Item</h2>

            <form method="POST" action="<?php echo e(route('food-item.update', $foodItem->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo e($foodItem->name); ?>">
                </div>

                <div class="form-group">
                    <label for="description">Description:</label>
                    <textarea class="form-control" id="description" name="description"><?php echo e($foodItem->description); ?></textarea>
                </div>

                <div class="form-group">
                    <label for="price">Price:</label>
                    <input type="text" class="form-control" id="price" name="price" value="<?php echo e($foodItem->price); ?>">
                </div>

                <div class="form-group">
                    <label for="category">Category:</label>
                    <select class="form-control" id="category" name="category">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryId => $categoryName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($categoryId); ?>" <?php if($categoryId==$foodItem->category_id): ?> selected
                            <?php endif; ?>><?php echo e($categoryName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="image">Upload Image:</label>
                    <input type="file" class="form-control-file" id="image" name="image">
                </div>

                <button type="submit" style="background: none; border: none; padding: 0; margin: 0; cursor: pointer;">
                    <img src="<?php echo e(asset('images/updatebutton.png')); ?>" alt="Add">
                </button>
            </form>

        </div>
    </center>
</body>

</html><?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/edit_food_item.blade.php ENDPATH**/ ?>