<p>
    Rp. <?php echo e(number_format($total, 0, '', '.')); ?>

</p>
<?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/livewire/components/subtotal.blade.php ENDPATH**/ ?>