<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Receipt</title>
    </head>
    <body>
        <div style="margin-left: 20vw; margin-right: 20vw">
            <div style="text-align: center;">
                <img src="<?php echo e(asset('images/terasedap_logo.png')); ?>" style="width: 200px" alt="">
            </div>
            <div>
                <div>
                    Order Number: <?php echo e($order->order_code); ?>

                </div>
                <div>Table Number: <?php echo e($order->table_number); ?></div>
                <div>Order Date: <?php echo e($order->updated_at); ?></div>
            </div>
            <div>
                <h1>Order Items</h1>
                <div>
                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div style="margin-bottom: 6px;">
                        <div style="padding: 4px;">
                            <div class="item-name">
                                <?php echo e($item->menu_name); ?>

                            </div>
                            <div>
                                <?php echo e($item->notes); ?>

                            </div>
                            <div style="display: flex; justify-content: space-between">
                                <div>
                                    x<?php echo e($item->quantity); ?> @ <span>Rp. <?php echo e(number_format($item->single_price, 0,'', '.')); ?></span>
                                </div>
                                <div>
                                    Rp. <?php echo e(number_format($item->total_price, 0,'', '.')); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div style="display: flex; justify-content: space-between">
                <h2>Subtotal</h2>
                <h2>
                    Rp. <?php echo e(number_format($order->total_price, 0, '', '.')); ?>

                </h2>
            </div>
        </div>
    </body>
</html><?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/receipt.blade.php ENDPATH**/ ?>