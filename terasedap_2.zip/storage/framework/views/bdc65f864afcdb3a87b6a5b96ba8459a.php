<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/livewire.css')); ?>">
<?php $__env->stopPush(); ?>
<div class="admin">
    <h2>Order History</h2>
    <div id="history">
        <div id="list-order">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="list-order-item" wire:click="selectOrder(<?php echo e($order->id); ?>)">
                <div>
                    <div class="item-code">
                        <?php echo e($order->order_code); ?>

                    </div>
                    <div style="font-size:12px; color: #9e9e9e">
                        <?php echo e(date_format($order->updated_at, 'd/m/Y')); ?>

                    </div>
                </div>
                <div class="item-status <?php echo e($order->status); ?>">
                    <?php echo e($order->status); ?>

                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
        </div>

        <div id="view-order">
            <!--[if BLOCK]><![endif]--><?php if(isset($selectedOrder)): ?>
            <div id="order-detail">
                <div style="display:flex; margin-bottom:16px;">
                    <div style="margin-right: 10px; width: max-content">
                        <p>Number</p>
                        <p>Order Date</p>
                        <p>Table</p>
                        <p>Payment</p>
                        <!--[if BLOCK]><![endif]--><?php if($selectedOrder->trashed()): ?>
                            <p>Canceled</p>
                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <div>
                        <p>: <?php echo e($selectedOrder->order_code); ?></p>
                        <p>: <?php echo e($selectedOrder->updated_at); ?></p>
                        <p>: <?php echo e($selectedOrder->table_number); ?></p>
                        <p>: <?php echo e(strtoupper($selectedOrder->payment_method)); ?></p>
                        <!--[if BLOCK]><![endif]--><?php if($selectedOrder->trashed()): ?>
                            : <?php echo e($selectedOrder->canceled->canceled_reason); ?>

                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>

                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $selectedOrder->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div style="margin-bottom: 6px;">
                    <div style="padding: 4px;">
                        <div class="item-name">
                            <?php echo e($item->menu_name); ?>

                        </div>
                        <div>
                            <?php echo e($item->notes); ?>

                        </div>
                        <div style="display: flex; justify-content: space-between">
                            <div>
                                x<?php echo e($item->quantity); ?> @ <span>Rp. <?php echo e(number_format($item->single_price, 0,'', '.')); ?></span>
                            </div>
                            <div>
                                Rp. <?php echo e(number_format($item->total_price, 0,'', '.')); ?>

                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
            <?php else: ?> 
            <div style="display: flex; align-items:center; justify-content:center; height: 100%; font-size:24px">
                Select an order
            </div>
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

        </div>
    </div>
</div><?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/livewire/order-history.blade.php ENDPATH**/ ?>