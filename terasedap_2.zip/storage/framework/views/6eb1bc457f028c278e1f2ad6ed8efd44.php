<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/styles.css')); ?>" />
    <title>Document</title>
</head>

<body>
    <nav>
        <center>
            <div class="logo">
                <img src="images/terasedap_logo.png" alt="logo" />
                <h2>Orders Recieved for the waiter</h2>
            </div>
        </center>
    </nav>
    <br>

    <?php if($orders->isEmpty()): ?>
    <p>No orders found.</p>
    <?php else: ?>
    <div class="order_background">
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h2>Meja <?php echo e($order->table_number); ?></h2>
        <ul>

            <li class="order">Order Date : <?php echo e($order->order_date); ?></li>

            <?php
            $totalPrice = 0; // Initialize total price for each order
            ?>

            <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="order">
                <?php echo e($item['food_item_name']); ?> | Rp.<?php echo e($item['food_item_price']); ?> X <?php echo e($item['quantity']); ?>

            </li>
            <?php
            // Calculate subtotal for each item and add to the total price
            $subtotal = $item['food_item_price'] * $item['quantity'];
            $totalPrice += $subtotal;
            ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <li class="order">Total: Rp.<?php echo e($totalPrice); ?></li>
            <li class="order">Pembayaran : <?php echo e($order->payment_method); ?></li>

        </ul>
        <br />
        <form method="POST" action="<?php echo e(route('orders.destroy', ['id' => $order->id])); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button class="orderbutton" type="submit">Sudah Bayar</button>
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>

</body>

</html><?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/orders.blade.php ENDPATH**/ ?>