<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/livewire.css')); ?>">
<?php $__env->stopPush(); ?>

<main>
    <div class="container admin">
        <p id="page-title">
            Menu Management
        </p>
        <div style="margin-top:20px">
            <a class="sign-button" href="<?php echo e(route('add-menu')); ?>">
                Add Menu
            </a>
        </div>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.menu-management', []);

$__html = app('livewire')->mount($__name, $__params, '6E87B8h', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
</main>
<?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/livewire/menu.blade.php ENDPATH**/ ?>