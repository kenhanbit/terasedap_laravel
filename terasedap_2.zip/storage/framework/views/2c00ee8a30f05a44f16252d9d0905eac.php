<style>
    #menu-manager {
        margin-top: 1.5rem;
    }

    #category-list {
        display: flex;
        justify-content: space-between;
        overflow:scroll;
    }

    li {
        list-style-type: none;
    }
    .category-list-item {
        display: grid;
        align-items: center;
        min-width: max-content;
        padding: 6px 1rem;
        border-radius: 20px;
        margin: 8px;
        overflow:hidden;
        background-color: #5F5A55;
        text-align: center;
        a {
            color: #dddddd;
            text-decoration: none;
        }
    }

    .category-list-item:hover {
        cursor: pointer;
    }

</style>
<div id="menu-manager">
    <ul id="category-list">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="category-list-item" onclick="scrollToSection('<?php echo e($category->name); ?>')">
            <a><?php echo e($category->name); ?></a>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
    </ul>
    <div id="admin-menu">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="scroll-target category-section" id="<?php echo e($category->name); ?>">
                <h2><?php echo e($category->name); ?></h2>
                <div class="menu-section">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $category->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('Components.AdminMenu', ['detail' => $food]);

$__html = app('livewire')->mount($__name, $__params, ''.e($food->id).'', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
    </div>
    
    <script>
        function scrollToSection(sectionId) {
            const section = document.getElementById(sectionId);
    
            if (section) {
                section.scrollIntoView({
                    behavior: "smooth"
                });
            }
        }
        </script>
</div>

<?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/livewire/components/menu-management.blade.php ENDPATH**/ ?>