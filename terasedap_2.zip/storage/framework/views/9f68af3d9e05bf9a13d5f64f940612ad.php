<div 
x-data="{ show: false, name: '<?php echo e($name); ?>' }"
x-show="show"
x-on:open-modal.window="console.log($event.detail);show = ($event.detail.name === name)"
x-on:close-modal.window="show = false"
style="z-index: -50; display:none;"
x-transition
>
    <div class="order-modal-background" x-on:click="show = false"></div>
    <div class="order-modal">
        <div class="modal-header">
            <div class="modal-title">
                Order Details
            </div>
            <div>
                <button style="background: none; border:none;" x-on:click="show = false">
                    <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('maki-cross'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'height:20px;']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                </button>
            </div>
        </div>
        <div class="modal-body">
            <div class="order-modal-detail">
                <div style="margin-right: 10px">
                    <p>Order Number</p>
                    <p>Order Time</p>
                    <p>Table Number</p>
                    <p>Payment Method</p>
                </div>
                <div>
                    <p>: <?php echo e($detail->order_code); ?></p>
                    <p>: <?php echo e($detail->order_date); ?></p>
                    <p>: <?php echo e($detail->table_number); ?></p>
                    <p>: <?php echo e($detail->payment_method); ?></p>
                </div>
            </div>
            <div class="order-modal-items" style="margin-top: 10px">
                <div>Order Items</div>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $detail->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item-detail">
                        <div>
                            <div style="margin-right:40px; display:flex;margin-bottom:4px;">
                                <div style="margin-right:10px;">
                                    <?php echo e($item->menu_name); ?>

                                </div>
                                <div>
                                    x <?php echo e($item->quantity); ?>

                                </div>
                            </div>
                            <div style="display: flex;overflow-wrap: break-word; max-width:200px; margin-left:10px">
                                <?php echo e($item->notes); ?>

                            </div>
                        </div>
                        <div>
                            Rp. <?php echo e(number_format($item->total_price, 0, '', '.')); ?> 
                            
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                <div class="detail-price" style="margin-top: 20px;">
                    <p>Total Payment</p>
                    <p>Rp. <?php echo e(number_format($detail->total_price, 0, '', '.')); ?></p>
                </div>
            </div>
        </div>
        <div class="modal-footer" style="display:flex; justify-content: space-between;">
            <button style="color: #fb3c2c; border: none; background: none; display:flex; align-items:center" x-on:click="$dispatch('open-delete-modal', {orderId : '<?php echo e($detail->id); ?>'})" orderId="<?php echo e($detail->id); ?>">
                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('iconsax-out-trash'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'height: 18px;']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?> Cancel Order
            </button>
            <div>
                <!--[if BLOCK]><![endif]--><?php switch($detail->status):
                    case ('unpaid'): ?>
                    <button class="modal-button received" wire:click="receiveOrder(<?php echo e($detail->id); ?>)">Receive</button>
                    <?php break; ?>
                    <?php case ('unpayed'): ?>
                    <button class="modal-button received" wire:click="receiveOrder(<?php echo e($detail->id); ?>)">Receive</button>
                    <?php break; ?>
                    <?php case ('received'): ?>
                    <button class="modal-button paid" style="background-color:#67f372" wire:click="payOrder(<?php echo e($detail->id); ?>)">Pay</button>
                    <?php break; ?>
                <?php endswitch; ?> <!--[if ENDBLOCK]><![endif]-->
                <button class="modal-button close" x-on:click="show = false">Close</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/livewire/components/orders-modal.blade.php ENDPATH**/ ?>