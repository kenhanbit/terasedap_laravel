<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/styles.css')); ?>" />
    <title>Terasedap | Add Menu</title>
</head>

<body>

    <div class="navbar">
        <div>
            <img src="images/terasedap_logo.png" alt="" />
        </div>
        <ul>
            <li><a href="<?php echo e(route('food-items')); ?>">Menu</a></li>
            <li><a href="<?php echo e(route('admin.history')); ?>">Orders History</a></li>
            <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            
                        </a>
                        <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();"
                            >Logout</a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>
                </ul>
            </li>
        </ul>
    </div>

    <div class="welcome-heading">
        <h1>Welcome to the admin panel</h1>
        <h2>Menu</h2>
        <select id="categoryFilter" onchange="filterFoodItems(this.value)">
            <option value="all">All</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryId => $categoryName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($categoryName); ?>"><?php echo e($categoryName); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <div class="menu-admin">
            <?php $__currentLoopData = $foodItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foodItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="menu-item-admin">
                <?php if($foodItem->image): ?>
                <img src="<?php echo e(asset('images/' . $foodItem->image)); ?>" class="menu-img" alt="Food Image">
                <?php endif; ?>
                <div class="food-name-admin"><?php echo e($foodItem->name); ?></div>
                <div class="food-categories-admin">
                    <?php echo e($foodItem->category->name); ?>

                </div>
                <div class="food-price-admin">Rp<?php echo e($foodItem->price); ?></div>
                <div class="food-name-admin"><?php echo e($foodItem->description); ?></div>
                <div class="edit-delete">
                    <a href="<?php echo e(route('food_items.editForm', $foodItem->id)); ?>">
                        <img src="images/editbutton.png" class="btn-img" alt="">
                    </a>
                    <form method="POST" action="<?php echo e(route('food_items.destroy', $foodItem->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" style="background: none; border: none; padding: 0; margin: 0; cursor: pointer;">
                            <img src="images/deletebutton.png" class="btn-img" alt="Delete">
                        </button>
                    </form>

                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>


    <center>
        <h1>Add New Menu Item</h1>
        <form action="<?php echo e(route('fooditem.store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="text" name="name" placeholder="Food Item Name"><br>
            <input type="number" name="price" placeholder="Price"><br>
            <textarea name="description" placeholder="Description"></textarea><br>
            <select name="category">
                <option value="">Select Category</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryId => $categoryName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($categoryId); ?>"><?php echo e($categoryName); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select><br>
            <input type="file" name="image"><br>
            <button type="submit" style="background: none; border: none; padding: 0; margin: 0; cursor: pointer;">
                <img src="images/addnewbutton.png" alt="Add">
            </button>
        </form>
    </center>
</body>

<script>
    function filterFoodItems(categoryId) {
        var menuItems = document.querySelectorAll('.menu-item-admin');

        menuItems.forEach(function (item) {
            var category = item.querySelector('.food-categories-admin').innerText.trim();

            if (categoryId === 'all' || category === categoryId) {
                item.style.display = 'block';
            } else {
                item.style.display = 'none';
            }
        });
    }
</script>


</html>

<?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/add_food_item.blade.php ENDPATH**/ ?>