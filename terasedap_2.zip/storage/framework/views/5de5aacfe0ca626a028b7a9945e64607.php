<!-- menu.blade.php -->
<!DOCTYPE html>
<html>

<head>
    <title>Restaurant Menu</title>
</head>

<body>
    <h1>Restaurant Menu</h1>
    <ul>
        <?php $__currentLoopData = $foodItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <strong>Name:</strong> <?php echo e($item->name); ?><br>
            <strong>Price:</strong> $<?php echo e($item->price); ?><br>
            <strong>Category:</strong> <?php echo e($item->category); ?><br>
            <strong>Description:</strong> <?php echo e($item->description); ?><br><br>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</body>

</html><?php /**PATH C:\kuliah\webProgramming\UAS\terasedap_project\terasedap_laravel\resources\views/menu.blade.php ENDPATH**/ ?>