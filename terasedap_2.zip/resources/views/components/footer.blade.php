<div>
   
    <footer>
        <div class="row">
            <div class="col">
                <img src="{{ asset('images/terasedap_logo.png')}}" class="logofoot">
                <div class="col">
                    {{-- <div class="media">
                        <a href="https://www.instagram.com/terasedap/" style="color: #e9e9e9; display:flex; align-items:center;">
                            <x-mdi-instagram style="width: 15px; margin-right: 8px;" />@terasedap
                        </a>
                    </div>
                    <div class="media">
                        <a href="https://wa.me/08111588389">
                            <x-mdi-whatsapp style="width: 15px; margin-right: 8px;" />+62 08111588389

                        </a>
                    </div>
                    <div class="media">
                        <x-mdi-email-outline style="width: 15px"  />
                    </div>
                    <div class="media">
                        <a href="https://gofood.link/a/yM9kNZf">
                            Gojek
                        </a>
                    </div> --}}
                </div> 
            </div>
            <div class="col">
                <h3>Location</h3>
                {{-- <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.0569791876837!2d106.61212437499057!3d-6.256224393732283!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69fc650b54f11b%3A0x3a05f67be3dd58f1!2steraSedap!5e0!3m2!1sen!2sid!4v1701787409996!5m2!1sen!2sid" width="300" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe> --}}
            </div>
        </div>
    </footer>
</div>