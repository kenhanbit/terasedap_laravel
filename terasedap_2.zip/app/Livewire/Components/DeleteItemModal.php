<?php

namespace App\Livewire\Components;

use Livewire\Component;

class DeleteItemModal extends Component
{
    public function render()
    {
        return view('livewire.components.delete-item-modal');
    }
}
